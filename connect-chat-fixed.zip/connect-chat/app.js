const SUPABASE_URL="https://dojbdphyeovfmiakhdoj.supabase.co";
const SUPABASE_KEY="sb_publishable_ZsbYKh3XLfN3BPukXUbvtg_Ho2At9dt";
const headers={"apikey":SUPABASE_KEY,"Authorization":"Bearer "+SUPABASE_KEY,"Content-Type":"application/json"};
const $=id=>document.getElementById(id);
let me=JSON.parse(localStorage.getItem("cc_user")||"null"), current=null, poll=null, deferredInstall=null;

function esc(v){return String(v??"")}
function avatar(name,url){return url?`<img src="${esc(url)}" alt="">`:esc((name||"?").trim().charAt(0).toUpperCase()||"?")}
async function api(path,opt={}){let r=await fetch(SUPABASE_URL+"/rest/v1/"+path,{...opt,headers:{...headers,...(opt.headers||{})}}); if(!r.ok) throw new Error(await r.text()); return r.status===204?null:r.json()}
function show(id){["welcome","home","chat"].forEach(x=>$(x).classList.toggle("hidden",x!==id))}
function setStatus(t,err=false){$("status").textContent=t||"";$("status").className="status"+(err?" error":"")}
async function connect(){
  const name=$("username").value.trim().replace(/\s+/g," ");
  if(name.length<2)return setStatus("Username must be at least 2 characters.",true);
  setStatus("Connecting...");
  try{
    const found=await api(`users?select=id,username&username=eq.${encodeURIComponent(name)}&limit=1`);
    if(found.length) me=found[0];
    else {
      me={id:crypto.randomUUID(),username:name};
      await api("users",{method:"POST",headers:{"Prefer":"return=representation"},body:JSON.stringify(me)});
    }
    localStorage.setItem("cc_user",JSON.stringify(me));
    await enterHome();
  }catch(e){setStatus("Could not connect. Check Supabase table/policies.",true);console.error(e)}
}
async function enterHome(){ $("meName").textContent="@"+me.username; show("home"); await loadUsers(); }
async function loadUsers(){
  const list=$("chatList"); list.innerHTML="";
  try{
    const users=await api(`users?select=id,username&order=created_at.desc`);
    const others=users.filter(u=>u.id!==me.id);
    if(!others.length){list.innerHTML='<div class="list-empty">No other users yet.<br>Ask someone to join with their username.</div>';return}
    others.forEach(u=>{let el=document.createElement("div");el.className="chatitem";el.innerHTML=`<div class="avatar">${avatar(u.username)}</div><div class="friendinfo"><strong>${esc(u.username)}</strong><span>Tap to chat</span></div>`;el.onclick=()=>openChat(u);list.appendChild(el)})
  }catch(e){list.innerHTML='<div class="list-empty error">Could not load users.</div>'}
}
async function openChat(u){current=u;$("friendName").textContent="@"+u.username;$("friendAvatar").innerHTML=avatar(u.username);show("chat");await loadMessages();clearInterval(poll);poll=setInterval(loadMessages,3000);$("messageInput").focus()}
async function loadMessages(){
  if(!current)return;
  try{
    const q=`messages?select=*&or=(sender_id.eq.${encodeURIComponent(me.id)},receiver_id.eq.${encodeURIComponent(me.id)})&order=created_at.asc`;
    const all=await api(q); const rows=all.filter(m=>(m.sender_id===me.id&&m.receiver_id===current.id)||(m.sender_id===current.id&&m.receiver_id===me.id));
    const box=$("messages");box.innerHTML=rows.length?"":'<div class="empty">Say hello 💗</div>';
    rows.forEach(m=>{let d=document.createElement("div");d.className="bubble "+(m.sender_id===me.id?"mine":"theirs");d.textContent=m.content;box.appendChild(d)});box.scrollTop=box.scrollHeight;
  }catch(e){console.error(e)}
}
async function send(e){e.preventDefault();let text=$("messageInput").value.trim();if(!text||!current)return;$("messageInput").value="";try{await api("messages",{method:"POST",body:JSON.stringify({id:crypto.randomUUID(),sender_id:me.id,receiver_id:current.id,content:text})});await loadMessages()}catch(err){console.error(err);alert("Message send failed. Check messages table/policies.")}}
function profile(){
  const saved=localStorage.getItem("cc_photo");$("profilePreview").innerHTML=avatar(me.username,saved);$("profileDialog").showModal()
}
$("connectBtn").onclick=connect;$("username").onkeydown=e=>{if(e.key==="Enter")connect()};
$("backBtn").onclick=()=>{clearInterval(poll);show("home");loadUsers()};$("sendForm").onsubmit=send;$("logoutBtn").onclick=()=>{clearInterval(poll);localStorage.removeItem("cc_user");me=null;show("welcome")};
$("profileBtn").onclick=profile;$("closeProfile").onclick=()=>$("profileDialog").close();
$("photoInput").onchange=e=>{let f=e.target.files?.[0];if(!f)return;if(f.size>4*1024*1024)return alert("Please choose an image under 4 MB.");let r=new FileReader();r.onload=()=>{localStorage.setItem("cc_photo",r.result);profile()};r.readAsDataURL(f)};
$("removePhoto").onclick=()=>{localStorage.removeItem("cc_photo");profile()};
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").classList.remove("hidden")});
$("installBtn").onclick=async()=>{if(!deferredInstall)return;deferredInstall.prompt();deferredInstall=null};
if("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(console.warn);
if(me) enterHome(); else show("welcome");
