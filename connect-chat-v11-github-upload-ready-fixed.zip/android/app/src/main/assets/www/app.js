const SUPABASE_URL="https://dojbdphyeovfmiakhdoj.supabase.co";
const SUPABASE_KEY="sb_publishable_ZsbYKh3XLfN3BPukXUbvtg_Ho2At9dt";
const headers={apikey:SUPABASE_KEY,Authorization:`Bearer ${SUPABASE_KEY}`,"Content-Type":"application/json"};
const $=id=>document.getElementById(id); let me=null,current=null,currentGroup=null,poll=null,signalPoll=null;
let pc=null,localStream=null,remoteStream=null,currentCallId=null,callRole=null,pendingOffer=null,callType='video',seenSignals=new Set(),pendingIce=[];
let groupPeers=new Map(), groupRemoteStreams=new Map(), groupCallId=null, groupCallRole=null, groupPendingIce=new Map();
let recorder=null,recChunks=[],recordCanvas=null,recordAnimation=null,audioContext=null,recordingMeta=null,callStartedAt=0,timer=null;
try{me=JSON.parse(localStorage.getItem('cc_user')||'null')}catch{}
async function api(path,opt={}){const r=await fetch(`${SUPABASE_URL}/rest/v1/${path}`,{...opt,headers:{...headers,...(opt.headers||{})}});const t=await r.text();if(!r.ok)throw Error(t||`HTTP ${r.status}`);return t?JSON.parse(t):null}
function uuid(){return crypto.randomUUID()} function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function avatar(n,url){return url?`<img src="${esc(url)}" alt="">`:esc((n||'?')[0].toUpperCase())}
function show(id){['welcome','home','chat'].forEach(x=>$(x).classList.toggle('hidden',x!==id))}
function status(t,e=false){$('status').textContent=t||'';$('status').className='status'+(e?' error':'')}
async function connect(){const name=$('username').value.trim().replace(/\s+/g,' ');if(name.length<2)return status('Username must be at least 2 characters.',true);try{status('Connecting...');const f=await api(`users?select=id,username&username=eq.${encodeURIComponent(name)}&limit=1`);if(f?.length)me=f[0];else{me={id:uuid(),username:name};await api('users',{method:'POST',body:JSON.stringify(me)})}localStorage.setItem('cc_user',JSON.stringify(me));await enterHome()}catch(e){console.error(e);status('Could not connect.',true)}}
async function enterHome(){$('meName').textContent='@'+me.username;show('home');await loadUsers();await loadContacts();await loadGroups()}
async function searchUsers(){const q=$('userSearch').value.trim();const box=$('searchResults');if(!q){box.innerHTML='';return}box.innerHTML='<div class="empty">Searching…</div>';try{const users=await api(`users?select=id,username&username=ilike.*${encodeURIComponent(q)}*&limit=20`);const rows=(users||[]).filter(u=>u.id!==me.id);if(!rows.length){box.innerHTML='<div class="empty">No user found.</div>';return}box.innerHTML='';for(const u of rows){const el=document.createElement('div');el.className='chatitem';el.innerHTML=`<div class="avatar">${avatar(u.username)}</div><div class="friendinfo"><strong>@${esc(u.username)}</strong><span>Search result</span></div><button class="addChatBtn">＋ Chat</button>`;el.querySelector('.addChatBtn').onclick=async e=>{e.stopPropagation();await addContact(u);};el.onclick=()=>openChat(u);box.appendChild(el)}}catch(e){console.error(e);box.innerHTML='<div class="empty error">Search failed.</div>'}}
async function addContact(u){try{await api('contacts',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates'},body:JSON.stringify({id:uuid(),user_id:me.id,contact_id:u.id})});await loadContacts();openChat(u)}catch(e){console.error(e);alert('Could not add this user. Run the V6 SQL once.')}}
async function loadContacts(){const list=$('contactsList');if(!list)return;try{const rows=await api(`contacts?user_id=eq.${me.id}&select=contact_id&order=created_at.desc`);const ids=[...new Set((rows||[]).map(x=>x.contact_id))];if(!ids.length){list.innerHTML='<div class="empty">Search a username to start a chat.</div>';return}const users=await api(`users?select=id,username&id=in.(${ids.join(',')})`);list.innerHTML='';users.forEach(u=>{const el=document.createElement('div');el.className='chatitem';el.innerHTML=`<div class="avatar">${avatar(u.username)}</div><div class="friendinfo"><strong>@${esc(u.username)}</strong><span>Open chat</span></div>`;el.onclick=()=>openChat(u);list.appendChild(el)})}catch(e){console.warn(e);list.innerHTML='<div class="empty">Search to add users.</div>'}}
async function loadUsers(){const list=$('chatList');list.innerHTML='';try{const [a,b,h]=await Promise.all([api(`messages?sender_id=eq.${me.id}&select=receiver_id&order=created_at.desc&limit=200`),api(`messages?receiver_id=eq.${me.id}&select=sender_id&order=created_at.desc&limit=200`),api(`chat_hidden?user_id=eq.${me.id}&select=other_user_id`)]);const hidden=new Set((h||[]).map(x=>x.other_user_id));const ids=[...new Set([...(a||[]).map(x=>x.receiver_id),...(b||[]).map(x=>x.sender_id)])].filter(id=>id!==me.id&&!hidden.has(id));if(!ids.length){list.innerHTML='<div class="empty">No chats yet.</div>';return}const users=await api(`users?select=id,username&id=in.(${ids.join(',')})`);users.forEach(u=>{const el=document.createElement('div');el.className='chatitem';el.innerHTML=`<div class="avatar">${avatar(u.username)}</div><div class="friendinfo"><strong>@${esc(u.username)}</strong><span>Tap to chat</span></div><button class="hidechat" title="Hide">🗑</button>`;el.onclick=e=>{if(e.target.closest('.hidechat'))return;openChat(u)};el.querySelector('.hidechat').onclick=async e=>{e.stopPropagation();await api('chat_hidden',{method:'POST',body:JSON.stringify({id:uuid(),user_id:me.id,other_user_id:u.id})});loadUsers()};list.appendChild(el)})}catch(e){console.error(e);list.innerHTML='<div class="empty error">Could not load chats.</div>'}}
async function loadGroups(){const list=$('groupList');if(!list)return;list.innerHTML='';try{const gm=await api(`group_members?user_id=eq.${me.id}&select=group_id`);const ids=(gm||[]).map(x=>x.group_id);if(!ids.length){list.innerHTML='<div class="empty">No groups yet.</div>';return}const gs=await api(`groups?select=id,name,owner_id&id=in.(${ids.join(',')})`);gs.forEach(g=>{const el=document.createElement('div');el.className='chatitem';el.innerHTML=`<div class="avatar">👥</div><div class="friendinfo"><strong>${esc(g.name)}</strong><span>${g.owner_id===me.id?'Owner · ':''}Group chat</span></div>${g.owner_id===me.id?'<button class="deleteGroupBtn" title="Delete group">🗑</button>':''}`;el.onclick=e=>{if(e.target.closest('.deleteGroupBtn'))return;openGroup(g)};const db=el.querySelector('.deleteGroupBtn');if(db)db.onclick=e=>{e.stopPropagation();deleteGroup(g)};list.appendChild(el)})}catch(e){console.error(e);list.innerHTML='<div class="empty error">Could not load groups.</div>'}}
async function openChat(u){await endCall(false);current=u;currentGroup=null;$('friendName').textContent='@'+u.username;$('friendAvatar').innerHTML=avatar(u.username);if(!$('blockUserBtn')){const b=document.createElement('button');b.id='blockUserBtn';b.className='callbtn danger';b.textContent='🚫';b.title='Block';b.onclick=blockCurrent;$('callButtons').parentElement.appendChild(b)}$('callButtons').classList.remove('hidden');$('groupCallButtons').classList.add('hidden');$('groupBadge').classList.add('hidden');$('deleteGroupBtnChat').classList.add('hidden');show('chat');await loadMessages();clearInterval(poll);poll=setInterval(loadMessages,2500);startSignalPolling();await findFreshIncomingCall();$('messageInput').focus()}
async function openGroup(g){await endCall(false);current=null;currentGroup=g;$('friendName').textContent=g.name;$('friendAvatar').innerHTML='👥';$('callButtons').classList.add('hidden');$('groupCallButtons').classList.remove('hidden');$('groupBadge').classList.remove('hidden');$('deleteGroupBtnChat').classList.toggle('hidden',g.owner_id!==me.id);show('chat');await loadGroupMessages();clearInterval(poll);poll=setInterval(loadGroupMessages,2500);$('messageInput').focus()}
function renderMessage(m){const mine=m.sender_id===me.id;const d=document.createElement('div');d.className=`bubble ${mine?'mine':'theirs'}`;let raw=String(m.message??m.content??'');let type=m.message_type||'text';const legacy=raw.match(/^\[(IMAGE|VIDEO)\](https?:\/\/\S+)$/i);if(legacy){type=legacy[1].toLowerCase()==='image'?'image':'video';raw=legacy[2]}if(type==='audio'){const a=document.createElement('audio');a.src=raw;a.controls=true;a.preload='metadata';d.appendChild(a)}else if(type==='image' || /^https?:\/\/\S+\.(?:jpg|jpeg|png|gif|webp|bmp)(?:\?.*)?$/i.test(raw)){const img=document.createElement('img');img.src=raw;img.alt='Image';img.loading='lazy';img.decoding='async';img.style.maxWidth='min(100%,320px)';img.style.maxHeight='420px';img.style.objectFit='cover';img.style.borderRadius='12px';img.style.display='block';img.onerror=()=>{d.textContent='Image could not be loaded';};d.appendChild(img)}else if(type==='video' || /^https?:\/\/\S+\.(?:mp4|webm|mov|m4v)(?:\?.*)?$/i.test(raw)){const v=document.createElement('video');v.src=raw;v.controls=true;v.playsInline=true;v.preload='metadata';v.style.maxWidth='min(100%,320px)';v.style.maxHeight='420px';v.style.borderRadius='12px';d.appendChild(v)}else d.textContent=raw;return d}
async function loadMessages(){if(!current)return;try{const rows=await api(`messages?select=*&or=(sender_id.eq.${me.id},receiver_id.eq.${me.id})&order=created_at.asc`);const box=$('messages');box.innerHTML='';const use=(rows||[]).filter(m=>(m.sender_id===me.id&&m.receiver_id===current.id)||(m.sender_id===current.id&&m.receiver_id===me.id));if(!use.length)box.innerHTML='<div class="empty">Say hello 💗</div>';use.forEach(m=>box.appendChild(renderMessage(m)));box.scrollTop=box.scrollHeight}catch(e){console.error(e)}}
async function loadGroupMessages(){if(!currentGroup)return;try{const rows=await api(`group_messages?group_id=eq.${currentGroup.id}&select=*&order=created_at.asc`);const box=$('messages');box.innerHTML='';if(!rows?.length)box.innerHTML='<div class="empty">Start the group chat 👥</div>';for(const m of rows||[]){const d=renderMessage(m);if(m.sender_id!==me.id){const u=await api(`users?select=username&id=eq.${m.sender_id}&limit=1`);const tag=document.createElement('small');tag.textContent='@'+(u?.[0]?.username||'user');d.prepend(tag)}box.appendChild(d)}box.scrollTop=box.scrollHeight}catch(e){console.error(e)}}
async function send(e){e.preventDefault();const text=$('messageInput').value.trim();if(!text)return;if(current){await api('messages',{method:'POST',body:JSON.stringify({id:uuid(),sender_id:me.id,receiver_id:current.id,message:text,message_type:'text'})});$('messageInput').value='';loadMessages()}else if(currentGroup){await api('group_messages',{method:'POST',body:JSON.stringify({id:uuid(),group_id:currentGroup.id,sender_id:me.id,message:text,message_type:'text'})});$('messageInput').value='';loadGroupMessages()}}
async function sendMedia(file){if(!file||(!current&&!currentGroup))return;const kind=file.type.startsWith('image/')?'image':file.type.startsWith('video/')?'video':null;if(!kind)return alert('Only image or video files are supported.');if(file.size>15*1024*1024)return alert('Maximum file size is 15 MB.');const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,'_');const path=`${me.id}/${uuid()}-${safe}`;try{const upload=async(method)=>fetch(`${SUPABASE_URL}/storage/v1/object/chat-media/${path}`,{method,headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${SUPABASE_KEY}`,'Content-Type':file.type,'x-upsert':'true','cache-control':'3600'},body:file});let r=await upload('POST');if(!r.ok){const first=await r.text();console.warn('Storage POST failed:',r.status,first);r=await upload('PUT');if(!r.ok){const second=await r.text();throw Error(`Storage upload failed (${r.status}): ${second||first}`)}}const url=`${SUPABASE_URL}/storage/v1/object/public/chat-media/${path}`;if(current)await api('messages',{method:'POST',body:JSON.stringify({id:uuid(),sender_id:me.id,receiver_id:current.id,message:url,message_type:kind})});else await api('group_messages',{method:'POST',body:JSON.stringify({id:uuid(),group_id:currentGroup.id,sender_id:me.id,message:url,message_type:kind})});current?loadMessages():loadGroupMessages()}catch(e){console.error(e);alert(`Media send failed.\n\n${e.message||e}`)}}
async function createGroup(){const name=prompt('Group name?')?.trim();if(!name)return;const raw=prompt('Member usernames, comma separated (you can include yourself):')||'';const names=[...new Set(raw.split(',').map(x=>x.trim().replace(/^@/,'' )).filter(Boolean))];try{const users=names.length?await api(`users?select=id,username&username=in.(${names.map(encodeURIComponent).join(',')})`):[];const g=(await api('groups',{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify({id:uuid(),name,owner_id:me.id})}))[0];const ids=[me.id,...(users||[]).map(u=>u.id)];for(const id of [...new Set(ids)])await api('group_members',{method:'POST',body:JSON.stringify({id:uuid(),group_id:g.id,user_id:id})});await loadGroups();openGroup(g)}catch(e){console.error(e);alert('Group creation failed')}}

async function deleteGroup(g){if(g.owner_id!==me.id)return alert('Only the group owner can delete this group.');if(!confirm(`Delete group "${g.name}" for everyone?`))return;try{await api(`groups?id=eq.${g.id}`,{method:'DELETE'});if(currentGroup?.id===g.id){currentGroup=null;await endGroupCall(false);clearInterval(poll);show('home')}await loadGroups()}catch(e){console.error(e);alert('Group delete failed: '+e.message)}}
async function groupMemberIds(){if(!currentGroup)return [];const rows=await api(`group_members?group_id=eq.${currentGroup.id}&select=user_id`);return [...new Set((rows||[]).map(x=>x.user_id).filter(id=>id!==me.id))]}
function clearRemoteGrid(){const grid=$('remoteGrid');if(grid)grid.innerHTML='';groupRemoteStreams.clear()}
function addGroupRemote(peerId,stream){groupRemoteStreams.set(peerId,stream);const grid=$('remoteGrid');if(!grid)return;let v=document.getElementById('groupRemote-'+peerId);if(!v){v=document.createElement('video');v.id='groupRemote-'+peerId;v.autoplay=true;v.playsInline=true;v.className='group-remote-video';grid.appendChild(v)}v.srcObject=stream;v.muted=false;v.play().catch(()=>{})}
function setupGroupPeer(peerId,initiator=false){const p=new RTCPeerConnection(rtcConfig());const rs=new MediaStream();groupPeers.set(peerId,{pc:p,stream:rs});
for(const c of (groupPendingIce.get(peerId)||[])){p.addIceCandidate(c).catch(()=>{})}groupPendingIce.delete(peerId);p.ontrack=e=>{(e.streams?.[0]?.getTracks()||[e.track]).forEach(t=>{if(!rs.getTracks().some(x=>x.id===t.id))rs.addTrack(t)});addGroupRemote(peerId,rs)};p.onicecandidate=e=>{if(e.candidate&&groupCallId)sendGroupSignal('ice',peerId,e.candidate.toJSON()).catch(console.warn)};p.onconnectionstatechange=()=>{if(p.connectionState==='connected')$('callStatus').textContent=callType==='audio'?'Group audio connected':'Group video connected';if(['failed','closed','disconnected'].includes(p.connectionState)){} };for(const t of localStream.getTracks())p.addTrack(t,localStream);return p}
async function sendGroupSignal(type,receiverId,payload){if(!groupCallId||!currentGroup)return;await api('call_signals',{method:'POST',body:JSON.stringify({id:uuid(),call_id:groupCallId,sender_id:me.id,receiver_id:receiverId,signal_type:type,payload:{...payload,groupId:currentGroup.id,callType}})})}
async function startGroupCall(type){if(!currentGroup||groupCallId)return;callType=type;try{await getMedia(type);groupCallId=uuid();groupCallRole='caller';seenSignals=new Set();clearRemoteGrid();showCallPanel();$('videoStage').classList.add('group-stage');$('remoteVideo').classList.add('hidden');const members=await groupMemberIds();if(!members.length){alert('Add members to the group first.');return endGroupCall(false)}$('callStatus').textContent=type==='audio'?'Calling group…':'Calling group video…';for(const id of members){const p=setupGroupPeer(id,true);const offer=await p.createOffer();await p.setLocalDescription(offer);await sendGroupSignal('offer',id,{type:offer.type,sdp:offer.sdp})}}catch(e){console.error(e);alert('Group call could not start: '+e.message);await endGroupCall(false)}}
async function acceptGroupCall(){if(!pendingOffer||!pendingOffer.payload?.groupId||groupCallId)return;const o=pendingOffer;callType=o.payload.callType||'video';try{await getMedia(callType);groupCallId=o.call_id;groupCallRole='callee';clearRemoteGrid();showCallPanel();$('videoStage').classList.add('group-stage');$('remoteVideo').classList.add('hidden');const p=setupGroupPeer(o.sender_id,false);await p.setRemoteDescription(new RTCSessionDescription({type:o.payload.type,sdp:o.payload.sdp}));const a=await p.createAnswer();await p.setLocalDescription(a);await sendGroupSignal('answer',o.sender_id,{type:a.type,sdp:a.sdp});pendingOffer=null;$('incomingCall').classList.add('hidden')}catch(e){console.error(e);alert('Could not accept group call: '+e.message);await endGroupCall(false)}}
async function processGroupSignal(s){if(!s.payload?.groupId||s.payload.groupId!==currentGroup?.id)return false;if(s.signal_type==='offer'){if(groupCallId||pc)return true;pendingOffer=s;seenSignals.add(s.id);$('incomingFrom').textContent='Group: '+currentGroup.name;$('incomingTitle').textContent=s.payload.callType==='audio'?'Incoming group audio call':'Incoming group video call';$('incomingCall').classList.remove('hidden');return true}if(s.call_id!==groupCallId||s.sender_id===me.id)return true;seenSignals.add(s.id);const entry=groupPeers.get(s.sender_id);try{if(s.signal_type==='answer'&&entry&&!entry.pc.currentRemoteDescription){await entry.pc.setRemoteDescription(new RTCSessionDescription({type:s.payload.type,sdp:s.payload.sdp}))}else if(s.signal_type==='ice'){const c=new RTCIceCandidate(s.payload);if(entry){if(entry.pc.remoteDescription)await entry.pc.addIceCandidate(c).catch(()=>{});else{const q=groupPendingIce.get(s.sender_id)||[];q.push(c);groupPendingIce.set(s.sender_id,q)}}else{const q=groupPendingIce.get(s.sender_id)||[];q.push(c);groupPendingIce.set(s.sender_id,q)}}else if(s.signal_type==='hangup')await endGroupCall(false)}catch(e){console.warn(e)}return true}
async function endGroupCall(notify=true){if(notify&&groupCallId&&currentGroup){const members=await groupMemberIds().catch(()=>[]);await Promise.all(members.map(id=>sendGroupSignal('hangup',id,{reason:'ended'}).catch(()=>{})))}for(const {pc:p} of groupPeers.values())p.close();groupPeers.clear();clearRemoteGrid();groupPendingIce.clear();groupCallId=null;groupCallRole=null;$('callPanel').classList.add('hidden');$('incomingCall').classList.add('hidden');$('videoStage').classList.remove('group-stage');$('remoteVideo').classList.remove('hidden')}
function rtcConfig(){return{iceServers:[{urls:'stun:stun.l.google.com:19302'},{urls:'stun:stun1.l.google.com:19302'},{urls:'stun:stun.cloudflare.com:3478'}]}}
async function getMedia(type){if(!navigator.mediaDevices?.getUserMedia)throw new Error('Media access is not supported on this device.');if(localStream)return localStream;const audio={echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:1,sampleRate:48000};localStream=await navigator.mediaDevices.getUserMedia({video:type==='video'?{facingMode:'user',width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30,max:30}}:false,audio});$('localVideo').srcObject=localStream;await $('localVideo').play().catch(()=>{});return localStream}
function setupPC(){pc=new RTCPeerConnection(rtcConfig());remoteStream=new MediaStream();$('remoteVideo').srcObject=remoteStream;if($('remoteAudio'))$('remoteAudio').srcObject=remoteStream;pc.ontrack=e=>{(e.streams?.[0]?.getTracks()||[e.track]).forEach(t=>{if(!remoteStream.getTracks().some(x=>x.id===t.id))remoteStream.addTrack(t)});$('remotePlaceholder').classList.add('hidden');if(callType==='audio')$('remoteAudio')?.play().catch(()=>{});else $('remoteVideo').play().catch(()=>{})};pc.onicecandidate=e=>e.candidate&&sendSignal('ice',e.candidate.toJSON()).catch(console.warn);pc.onconnectionstatechange=()=>{const s=pc?.connectionState;$('callStatus').textContent=s==='connected'?(callType==='audio'?'Audio connected':'Video connected'):s==='failed'?'Connection failed':s==='connecting'?'Connecting…':s};for(const t of localStream.getTracks()){const sender=pc.addTrack(t,localStream);if(t.kind==='audio')try{const p=sender.getParameters();p.encodings=p.encodings?.length?p.encodings:[{}];p.encodings[0].maxBitrate=96000;p.encodings[0].dtx=false;sender.setParameters(p).catch(()=>{})}catch(e){}}}
async function sendSignal(type,payload){if(!currentCallId||!current)return;await api('call_signals',{method:'POST',body:JSON.stringify({id:uuid(),call_id:currentCallId,sender_id:me.id,receiver_id:current.id,signal_type:type,payload})})}
async function startCall(type){if(!current||pc)return;callType=type;try{await getMedia(type);currentCallId=uuid();callRole='caller';seenSignals=new Set();pendingIce=[];setupPC();showCallPanel();const offer=await pc.createOffer();await pc.setLocalDescription(offer);await sendSignal('offer',{type:offer.type,sdp:offer.sdp,callType:type});$('callStatus').textContent=type==='audio'?'Calling…':'Calling video…'}catch(e){console.error(e);alert('Microphone/camera permission is required: '+e.message);cleanupCall()}}
async function acceptCall(){if(!pendingOffer||pc)return;const o=pendingOffer;callType=o.payload.callType||'video';try{await getMedia(callType);callRole='callee';currentCallId=o.call_id;setupPC();showCallPanel();await pc.setRemoteDescription(new RTCSessionDescription(o.payload));for(const c of pendingIce)await pc.addIceCandidate(c).catch(console.warn);pendingIce=[];const a=await pc.createAnswer();await pc.setLocalDescription(a);await sendSignal('answer',{type:a.type,sdp:a.sdp});pendingOffer=null;$('incomingCall').classList.add('hidden')}catch(e){console.error(e);alert('Could not accept call: '+e.message);cleanupCall()}}
async function processSignal(s){
  if(seenSignals.has(s.id))return;
  if(s.payload?.groupId){await processGroupSignal(s);return}
  if(s.signal_type==='offer'&&s.receiver_id===me.id){
    seenSignals.add(s.id);
    if(current&&current.id===s.sender_id&&!pc&&!pendingOffer&&Date.now()-new Date(s.created_at).getTime()<60000){
      pendingOffer=s;$('incomingFrom').textContent='@'+current.username;$('incomingTitle').textContent=s.payload.callType==='audio'?'Incoming audio call':'Incoming video call';$('incomingCall').classList.remove('hidden');
    }
    return;
  }
  if(s.call_id!==currentCallId||s.sender_id===me.id){
    // Keep pre-accept ICE candidates; the callee may not have created RTCPeerConnection yet.
    if(s.signal_type==='ice'&&s.sender_id===current?.id&&s.call_id===pendingOffer?.call_id){
      pendingIce.push(new RTCIceCandidate(s.payload));
    }
    return;
  }
  try{
    if(s.signal_type==='answer'&&callRole==='caller'&&!pc.currentRemoteDescription){
      seenSignals.add(s.id);
      await pc.setRemoteDescription(new RTCSessionDescription(s.payload));
      for(const c of pendingIce)await pc.addIceCandidate(c).catch(()=>{});pendingIce=[];
    }else if(s.signal_type==='ice'){
      seenSignals.add(s.id);
      const c=new RTCIceCandidate(s.payload);
      if(pc.remoteDescription)await pc.addIceCandidate(c).catch(()=>{});else pendingIce.push(c);
    }else if(s.signal_type==='hangup'){seenSignals.add(s.id);cleanupCall()}
  }catch(e){console.warn('Signal processing failed',e)}
}
async function refreshSignals(){if(!me)return;try{const rows=await api(`call_signals?receiver_id=eq.${me.id}&order=created_at.asc&limit=100`);for(const s of rows||[])await processSignal(s)}catch(e){console.warn(e)}}
function startSignalPolling(){clearInterval(signalPoll);refreshSignals();signalPoll=setInterval(refreshSignals,800)}
async function findFreshIncomingCall(){if(!current||pc||pendingOffer)return;try{const rows=await api(`call_signals?receiver_id=eq.${me.id}&sender_id=eq.${current.id}&signal_type=eq.offer&order=created_at.desc&limit=5`);const f=(rows||[]).find(s=>Date.now()-new Date(s.created_at).getTime()<30000);if(f){pendingOffer=f;seenSignals.add(f.id);$('incomingFrom').textContent='@'+current.username;$('incomingTitle').textContent=f.payload.callType==='audio'?'Incoming audio call':'Incoming video call';$('incomingCall').classList.remove('hidden')}}catch(e){console.warn(e)}}
function showCallPanel(){$('callPanel').classList.remove('hidden');$('videoStage').classList.toggle('audio-only',callType==='audio');$('remotePlaceholder').textContent=callType==='audio'?'Connecting audio…':'Waiting for video…';$('localVideo').classList.toggle('hidden',callType==='audio');$('remoteVideo').classList.toggle('hidden',callType==='audio');$('remoteAudio')?.classList.toggle('hidden',callType!=='audio');$('callTypeLabel').textContent=callType==='audio'?'Audio call':'Video call';$('callPeerName').textContent=current?.username?'@'+current.username:(currentGroup?.name||'Connect Chat');callStartedAt=Date.now();clearInterval(timer);timer=setInterval(()=>{const s=Math.floor((Date.now()-callStartedAt)/1000);$('callTimer').textContent=`${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`},1000)}
function supportedMime(){
  const types=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm','audio/webm;codecs=opus','audio/webm'];
  return types.find(t=>MediaRecorder.isTypeSupported(t))||'';
}
function setupRecorder(){
  if(recorder)return recorder;
  if(!currentCallId||!localStream)return null;
  if(callType==='video' && (!remoteStream || !remoteStream.getVideoTracks().length))return null;
  recordingMeta={callId:currentCallId,callerId:callRole==='caller'?me.id:current.id,receiverId:callRole==='caller'?current.id:me.id,startedAt:new Date().toISOString()};
  let out=new MediaStream();
  if(callType==='video'){
    const rv=$('remoteVideo'),lv=$('localVideo');
    recordCanvas=document.createElement('canvas');recordCanvas.width=1280;recordCanvas.height=720;
    const ctx=recordCanvas.getContext('2d');
    const draw=()=>{
      ctx.fillStyle='#000';ctx.fillRect(0,0,1280,720);
      if(rv.readyState>=2&&rv.videoWidth)ctx.drawImage(rv,0,0,1280,720);
      if(lv.readyState>=2&&lv.videoWidth)ctx.drawImage(lv,1080,20,180,250);
      recordAnimation=requestAnimationFrame(draw);
    };draw();out=recordCanvas.captureStream(30);
  }
  try{
    audioContext=new (window.AudioContext||window.webkitAudioContext)();
    const dest=audioContext.createMediaStreamDestination();
    const streams=[localStream,remoteStream].filter(Boolean);
    for(const st of streams)for(const t of st.getAudioTracks()){try{audioContext.createMediaStreamSource(new MediaStream([t])).connect(dest)}catch(e){console.warn(e)}}
    dest.stream.getAudioTracks().forEach(t=>out.addTrack(t));
    audioContext.resume?.().catch(()=>{});
  }catch(e){
    console.warn('Audio mixer unavailable',e);
    for(const t of localStream.getAudioTracks())out.addTrack(t);
    if(remoteStream)for(const t of remoteStream.getAudioTracks())out.addTrack(t);
  }
  const mime=supportedMime();
  try{recorder=mime?new MediaRecorder(out,{mimeType:mime}):new MediaRecorder(out)}catch(e){console.error(e);recorder=null;return null}
  recChunks=[];
  recorder.ondataavailable=e=>{if(e.data&&e.data.size)recChunks.push(e.data)};
  recorder.onerror=e=>console.error('Recorder error',e);
  recorder.onstop=()=>uploadRecording();
  return recorder;
}
function toggleRecording(){
  if(!recorder){
    const r=setupRecorder();
    if(!r)return alert(callType==='video'?'Video must be connected first.':'Call is not connected yet.');
    try{r.start(1000);$('recordBtn').textContent='Stop recording';$('recordingIndicator').classList.remove('hidden')}catch(e){console.error(e);recorder=null;alert('Recording could not start: '+e.message)}
  }else if(recorder.state!=='inactive'){const r=recorder;try{r.stop()}catch(e){console.error(e)}}
}
async function uploadRecording(){
  cancelAnimationFrame(recordAnimation);
  const mime=(recChunks[0]?.type)|| (callType==='video'?'video/webm':'audio/webm');
  const ext=callType==='video'?'webm':'webm';
  const blob=new Blob(recChunks,{type:mime}),meta=recordingMeta;
  if(!meta||!blob.size){recorder=null;recChunks=[];recordingMeta=null;return}
  const path=`recordings/${me.id}/${meta.callId}-${Date.now()}.${ext}`;
  const url=`${SUPABASE_URL}/storage/v1/object/public/call-recordings/${path}`;
  const downloadName=`connect-chat-${callType}-recording-${new Date().toISOString().replace(/[:.]/g,'-')}.webm`;
  try{
    const headers2={apikey:SUPABASE_KEY,Authorization:`Bearer ${SUPABASE_KEY}`,'Content-Type':mime,'x-upsert':'true'};
    let r=await fetch(`${SUPABASE_URL}/storage/v1/object/call-recordings/${path}`,{method:'POST',headers:headers2,body:blob});
    if(!r.ok){const msg=await r.text();console.warn('Recording POST failed',r.status,msg);r=await fetch(`${SUPABASE_URL}/storage/v1/object/call-recordings/${path}`,{method:'PUT',headers:headers2,body:blob})}
    let cloudSaved=r.ok;
    if(cloudSaved){
      await api('call_recordings',{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify({id:uuid(),call_id:meta.callId,caller_id:meta.callerId,receiver_id:meta.receiverId,recording_type:callType,file_name:path.split('/').pop(),mime_type:mime,size_bytes:blob.size,duration_seconds:Math.floor((Date.now()-callStartedAt)/1000),started_at:meta.startedAt,ended_at:new Date().toISOString(),storage_path:path,storage_url:url})}).catch(e=>{console.warn('Recording metadata save failed',e);cloudSaved=false});
    }
    // Always keep a device copy so a storage/network failure never destroys the recording.
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=downloadName;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},2000);
    alert(cloudSaved?'Recording saved to cloud and downloaded to this device.':'Recording downloaded to this device. Cloud save was unavailable.');
  }catch(e){
    console.error('Recording save error',e);
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=downloadName;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},2000);
    alert('Recording downloaded to this device.');
  }finally{recorder=null;recChunks=[];recordingMeta=null;audioContext?.close().catch(()=>{});audioContext=null;$('recordBtn').textContent='Start recording';$('recordingIndicator').classList.add('hidden')}
}
async function endCall(notify=true){const id=currentCallId;if(notify&&id)sendSignal('hangup',{reason:'ended'}).catch(()=>{});if(recorder&&recorder.state!=='inactive'){recorder.stop();setTimeout(()=>cleanupCall(id),1500)}else cleanupCall(id)}
function cleanupCall(){cancelAnimationFrame(recordAnimation);clearInterval(timer);clearInterval(signalPoll);timer=null;pc?.close();pc=null;localStream?.getTracks().forEach(t=>t.stop());localStream=null;remoteStream=null;currentCallId=null;callRole=null;pendingOffer=null;pendingIce=[];$('callPanel').classList.add('hidden');$('incomingCall').classList.add('hidden');$('localVideo').srcObject=null;$('remoteVideo').srcObject=null;if($('remoteAudio'))$('remoteAudio').srcObject=null;$('callStatus').textContent='Connect Chat'}
async function logout(){await endCall(false);await endGroupCall(false);clearInterval(poll);clearInterval(signalPoll);me=null;current=null;currentGroup=null;localStorage.removeItem('cc_user');$('profileDialog').close();show('welcome');$('username').value='';status('Logged out.');}
function profile(){const p=localStorage.getItem('cc_photo_'+me.id);$('profilePreview').innerHTML=avatar(me.username,p);$('profileDialog').showModal()}

// ===== V11 FEATURE PACK =====
let replyTo=null, voiceRecorder=null, voiceChunks=[];
function setReply(m){replyTo=m;$('replyBar').classList.remove('hidden');$('replyBar').innerHTML=`↩ Replying to: <b>${esc((m.message||'').slice(0,90))}</b> <button id="cancelReply">×</button>`;$('cancelReply').onclick=()=>{replyTo=null;$('replyBar').classList.add('hidden')};$('messageInput').focus()}
function enhanceMessage(d,m){
  const actions=document.createElement('div');actions.className='msg-actions';
  const rb=document.createElement('button');rb.textContent='↩';rb.title='Reply';rb.onclick=e=>{e.stopPropagation();setReply(m)};actions.appendChild(rb);
  if(m.sender_id===me.id){const eb=document.createElement('button');eb.textContent='✏️';eb.title='Edit';eb.onclick=async e=>{e.stopPropagation();const n=prompt('Edit message',m.message||'');if(n!==null&&n.trim()){await api(`messages?id=eq.${m.id}`,{method:'PATCH',body:JSON.stringify({message:n.trim(),edited_at:new Date().toISOString()})});loadMessages()}};actions.appendChild(eb)}
  d.appendChild(actions); return d;
}
const _renderMessage=renderMessage;
renderMessage=function(m){const d=_renderMessage(m);if((m.message_type||'text')==='text')enhanceMessage(d,m);return d}
async function sendEnhanced(e){e.preventDefault();const text=$('messageInput').value.trim();if(!text)return;try{if(current){const body={id:uuid(),sender_id:me.id,receiver_id:current.id,message:text,message_type:'text'};if(replyTo){body.reply_to_id=replyTo.id;body.reply_preview=(replyTo.message||'').slice(0,200)}await api('messages',{method:'POST',body:JSON.stringify(body)})}else if(currentGroup){await api('group_messages',{method:'POST',body:JSON.stringify({id:uuid(),group_id:currentGroup.id,sender_id:me.id,message:text,message_type:'text'})})}$('messageInput').value='';replyTo=null;$('replyBar').classList.add('hidden');current?loadMessages():loadGroupMessages()}catch(e){alert('Message failed: '+e.message)}}
async function startVoiceMessage(){
  if(!current&&!currentGroup)return;

  // Second tap stops the recording. Do not use a 1-second timeslice here:
  // some Android WebView versions finalize MediaRecorder chunks too early.
  if(voiceRecorder){
    try{voiceRecorder.stop()}catch(e){console.warn('Voice stop error',e)}
    return
  }

  if(!navigator.mediaDevices?.getUserMedia)
    return alert('Microphone is not supported.');

  let st=null;
  try{
    st=await navigator.mediaDevices.getUserMedia({
      audio:{
        echoCancellation:true,
        noiseSuppression:true,
        autoGainControl:true,
        channelCount:1,
        sampleRate:48000
      }
    });

    const mime=['audio/webm;codecs=opus','audio/webm'].find(x=>MediaRecorder.isTypeSupported(x))||'';
    voiceChunks=[];
    const rec=mime
      ?new MediaRecorder(st,{mimeType:mime,audioBitsPerSecond:128000})
      :new MediaRecorder(st);
    voiceRecorder=rec;

    const startedAt=Date.now();
    $('voiceBtn').textContent='⏹';
    $('voiceBtn').title='Stop voice recording';

    rec.ondataavailable=e=>{
      if(e.data&&e.data.size)voiceChunks.push(e.data)
    };
    rec.onerror=e=>console.warn('Voice recorder error',e);

    rec.onstop=async()=>{
      try{
        // Give Android WebView a moment to deliver the final dataavailable event.
        await new Promise(r=>setTimeout(r,250));
        const blob=new Blob(voiceChunks,{type:rec.mimeType||'audio/webm'});
        const durationMs=Date.now()-startedAt;
        if(durationMs<300 || blob.size<1000)
          throw Error('Voice recording was too short.');

        const path=`${me.id}/${uuid()}-voice.webm`;
        const h={
          apikey:SUPABASE_KEY,
          Authorization:`Bearer ${SUPABASE_KEY}`,
          'Content-Type':blob.type||'audio/webm',
          'x-upsert':'true'
        };
        let r=await fetch(`${SUPABASE_URL}/storage/v1/object/chat-media/${path}`,{
          method:'POST',headers:h,body:blob
        });
        if(!r.ok)r=await fetch(`${SUPABASE_URL}/storage/v1/object/chat-media/${path}`,{
          method:'PUT',headers:h,body:blob
        });
        if(!r.ok)throw Error(await r.text());

        const url=`${SUPABASE_URL}/storage/v1/object/public/chat-media/${path}`;
        if(current){
          await api('messages',{
            method:'POST',
            body:JSON.stringify({
              id:uuid(),sender_id:me.id,receiver_id:current.id,
              message:url,message_type:'audio'
            })
          });
        }else{
          await api('group_messages',{
            method:'POST',
            body:JSON.stringify({
              id:uuid(),group_id:currentGroup.id,sender_id:me.id,
              message:url,message_type:'audio'
            })
          });
        }
        current?loadMessages():loadGroupMessages();
      }catch(e){
        alert('Voice message failed: '+e.message)
      }finally{
        st?.getTracks().forEach(t=>t.stop());
        voiceRecorder=null;
        voiceChunks=[];
        $('voiceBtn').textContent='🎤';
        $('voiceBtn').title='Voice message';
      }
    };

    // No timeslice: keep the entire recording in one final WebM/Opus blob.
    rec.start();
  }catch(e){
    st?.getTracks().forEach(t=>t.stop());
    voiceRecorder=null;
    $('voiceBtn').textContent='🎤';
    $('voiceBtn').title='Voice message';
    alert('Microphone permission required: '+(e.message||e));
  }
}
$('voiceBtn').onclick=startVoiceMessage;
$('callHistoryBtn').onclick=showCallHistory;$('blockedBtn').onclick=showBlocked;$('closeHistory').onclick=()=>$('historyDialog').close();$('closeBlocked').onclick=()=>$('blockedDialog').close();
// Audio message rendering
const oldLoadMessages=loadMessages;
loadMessages=async function(){await oldLoadMessages();document.querySelectorAll('#messages .bubble').forEach(d=>{const mtxt=d.textContent?.trim();if(/^https?:\/\//.test(mtxt)&&d.querySelector('img')===null){}})};

$('connectBtn').onclick=connect;$('userSearch').oninput=searchUsers;$('username').onkeydown=e=>e.key==='Enter'&&connect;$('sendForm').onsubmit=send;$('videoBtn').onclick=()=>startCall('video');$('audioBtn').onclick=()=>startCall('audio');$('groupVideoBtn').onclick=()=>startGroupCall('video');$('groupAudioBtn').onclick=()=>startGroupCall('audio');$('acceptBtn').onclick=()=>pendingOffer?.payload?.groupId?acceptGroupCall():acceptCall();$('declineBtn').onclick=()=>{pendingOffer=null;$('incomingCall').classList.add('hidden')};$('endCallBtn').onclick=()=>groupCallId?endGroupCall(true):endCall(true);$('recordBtn').onclick=toggleRecording;$('mediaBtn').onclick=()=>$('mediaInput').click();$('mediaInput').onchange=e=>{const f=e.target.files?.[0];if(f)sendMedia(f);e.target.value=''};$('createGroupBtn').onclick=createGroup;$('deleteGroupBtnChat').onclick=()=>currentGroup&&deleteGroup(currentGroup);$('backBtn').onclick=async()=>{await endCall(false);await endGroupCall(false);clearInterval(poll);show('home');enterHome()};$('profileBtn').onclick=profile;$('closeProfile').onclick=()=>$('profileDialog').close();$('logoutBtn').onclick=logout;$('photoInput').onchange=e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{localStorage.setItem('cc_photo_'+me.id,r.result);profile()};r.readAsDataURL(f)};$('removePhoto').onclick=()=>{localStorage.removeItem('cc_photo_'+me.id);profile()};startSignalPolling();if(me)enterHome();else show('welcome');if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js').catch(console.warn);window.addEventListener('beforeunload',()=>{if(currentCallId)navigator.sendBeacon(`${SUPABASE_URL}/rest/v1/call_signals?call_id=eq.${currentCallId}`,new Blob([],{type:'application/json'}))});
